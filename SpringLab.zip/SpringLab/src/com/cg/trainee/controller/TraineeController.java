package com.cg.trainee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	ITraineeService traineeService;
	
	
	@RequestMapping("/show")
	public String showHomePage(){
		return("login");
	}
	
	@RequestMapping("/validate")
	public ModelAndView validateCredential(@RequestParam("username") String str1,@RequestParam("pwd") String str2){
		
	
	if(str1.equalsIgnoreCase("skumar65") && str2.equals("12345")){
		return new ModelAndView("traineeSystem");
	}

		else{
			return new ModelAndView("loginError");
		}
	}
	@RequestMapping("/add")
	public String addDetail(){
		return("addTrainee");
	}
	@RequestMapping("/added")
	public ModelAndView addEmployee1(@ModelAttribute("trainee") Trainee trainee,BindingResult result){
		
		ModelAndView mv=new ModelAndView();

		if (!result.hasErrors()) {
		  Trainee t = traineeService.addTrainee(trainee);
			mv = new ModelAndView("addsuccess","trainee",t);
			
		} else {
			mv.setViewName("error");
			mv.addObject("msg","Binding Error!!!");
		}

		return mv;
	}
		
	
	@RequestMapping("/delete")
	public ModelAndView showdeletedetail(){
		Trainee trainee = new Trainee();
		ModelAndView mv = new ModelAndView("deleteTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");

		return mv;
	}
	@RequestMapping("/ondelete")
	public ModelAndView deleteEmployee(@ModelAttribute("t") Trainee t){
			ModelAndView mv=new ModelAndView();
			Trainee trainee=traineeService.getTrainee(t.getTraineeId());
			if(trainee!=null){
			mv.setViewName("deleteTrainee");
			mv.addObject("t", trainee);
		    }
			else{
				 mv.setViewName("error");
				 mv.addObject("msg","No Such Trainee is Available.!!!");
			}
			return mv;
		
	}
	@RequestMapping("/deleteSuccess")
	public ModelAndView deleteTrainee(@ModelAttribute("t") Trainee t){
		boolean status = traineeService.deleteTrainee(t.getTraineeId());
		if(status == true){
			List<Trainee> trainee=traineeService.getAllTrainees();
			ModelAndView mv=new ModelAndView("viewAllTrainee","trainee",trainee);
			return mv;
		}
		else{
			ModelAndView modelAndView = new ModelAndView("Error");		
			modelAndView.addObject("error", "Employee Details could not be deleted");
			return modelAndView;
		}
		
	}
	
	@RequestMapping("/retrieveall")
	public ModelAndView viewDetail(){
		List<Trainee> trainee=traineeService.getAllTrainees();
		ModelAndView mv=new ModelAndView();
		if(!trainee.isEmpty()){
	    mv=new ModelAndView("viewAllTrainee","trainee",trainee);
		return mv;
		}
		else {
			mv.setViewName("error");
			mv.addObject("msg","No Trainee Found!!");
			return mv;
		}
		
	}
	@RequestMapping("/retrieve")
	public ModelAndView showTraineeForm() {

		// Create an attribute of type Question
		Trainee trainee = new Trainee();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("retrieveTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");

		return mv;
	}
	@RequestMapping("/retrievenow")
	public ModelAndView viewDonation(@ModelAttribute("trainee") Trainee trainee) {

		ModelAndView mv = new ModelAndView();

		Trainee t = new Trainee();
		t = traineeService.getTrainee(trainee.getTraineeId());
	
	    if (t != null) {
		  mv.setViewName("retrieveTrainee");
		  mv.addObject("t", t);
	    } else {
		String msg = "Enter a Valid Id!!";
		mv.setViewName("error");
		mv.addObject("msg", msg);
	}

		return mv;
	}
	@RequestMapping("/modify")
	public ModelAndView showModifyForm(){
		Trainee trainee =new Trainee();
		
		ModelAndView mv=new ModelAndView("updateform");
		mv.addObject("trainee",trainee);
		mv.addObject("isFirst", "true");

		return mv;
		
	}
	@RequestMapping("/updateTrainee")
	public ModelAndView updateEmployee1(@ModelAttribute("t")  Trainee t){
		ModelAndView mv=new ModelAndView();
		Trainee trainee=traineeService.getTrainee(t.getTraineeId());
		if(trainee!=null){
		mv.setViewName("updateform");
		mv.addObject("t", trainee);
		}
		else{
			mv.setViewName("error");
			mv.addObject("msg","Please enter a valid Trainee ID!!");
		}
		return mv;
	}
	@RequestMapping("/updateSuccess")
	public ModelAndView updateTrainee(@ModelAttribute("t")  Trainee t,BindingResult result){
		ModelAndView mv=new ModelAndView();
		boolean status=traineeService.updateTrainee(t);
		if(result.hasErrors()){
			mv.setViewName("updateform");
		}else if(status==true){
		mv.setViewName("success");
		mv.addObject("message","updated successfully");
		
		
		}	
		return mv;
	}
	
}
	
	
	
	
