package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.entities.Trainee;

public interface ITraineeService {
	public Trainee addTrainee(Trainee trainee);
	 public boolean deleteTrainee(int id);
	 public boolean updateTrainee(Trainee trainee);
	 public List<Trainee> getAllTrainees();
	 public Trainee getTrainee(int id);

}
