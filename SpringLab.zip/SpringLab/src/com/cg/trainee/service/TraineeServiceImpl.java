package com.cg.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.ITraineeDao;
import com.cg.trainee.entities.Trainee;


@Service
public class TraineeServiceImpl implements ITraineeService {
	@Autowired
	ITraineeDao traineeDao;

	@Override
	public Trainee addTrainee(Trainee trainee) {
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public boolean deleteTrainee(int id) {
		return traineeDao.deleteTrainee(id);
	}

	@Override
	public boolean updateTrainee(Trainee trainee) {
		return traineeDao.updateTrainee(trainee);
	}

	@Override
	public List<Trainee> getAllTrainees() {
		return traineeDao.getAllTrainees();
	}

	@Override
	public Trainee getTrainee(int id) {
		return traineeDao.getTrainee(id);
	}

}
