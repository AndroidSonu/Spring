package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.entities.Trainee;


@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {
	
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Trainee addTrainee(Trainee trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public boolean deleteTrainee(int id) {
		Trainee trainee=entityManager.find(Trainee.class, id);
		entityManager.remove(trainee);
		return true;
	}

	@Override
	public boolean updateTrainee(Trainee trainee) {
		entityManager.merge(trainee);
		return true;
		
	}

	@Override
	public List<Trainee> getAllTrainees() {
		TypedQuery<Trainee> query = entityManager.createQuery(" FROM Trainee", Trainee.class);
		return query.getResultList();
	}

	@Override
	public Trainee getTrainee(int id) {
		return entityManager.find(Trainee.class, id);
	}

}
