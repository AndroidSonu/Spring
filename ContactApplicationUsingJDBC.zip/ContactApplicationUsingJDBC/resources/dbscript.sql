create table contacts(
	contid number(4)primary key,
	firstname varchar(15) not null,
	midname varchar(15)not null,
	lastname varchar(15) not null,
	gender varchar(10)not null,
	mobilenumber1 varchar(11)not null unique,
	mobilenumber2 varchar(11)not null unique,
	officialemail varchar(30)not null unique,
	homeemail varchar(30)not null unique,
	category varchar(10)not null,
	organization varchar(15)not null,
	designation varchar(20)not null
);

create sequence contidseq
start with 1
increment by 1;
