package com.cg.ca.dto;

public enum Category {
	HR,ASSOCIATE,CONSULTANT,DEVELOPER,ANALYST,OTHERS;
}
