package com.cg.ca.dto;

public enum Gender {
	MALE,FEMALE;
}
