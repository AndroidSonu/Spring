package com.cg.ca.ui;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.ca.dto.Category;
import com.cg.ca.dto.Contact;
import com.cg.ca.dto.Gender;
import com.cg.ca.exception.ContactException;
import com.cg.ca.service.ContactServiceImpl;
import com.cg.ca.service.IContactService;

public class ContactApp {
	static IContactService service;
	static Scanner scan;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			service = new ContactServiceImpl();
			System.out.println("service started!");
		} catch (ContactException exp) {
			System.err.println(exp.getMessage());
			System.exit(0);
		}

		PropertyConfigurator.configure("resources/log4j.properties");
		UserMenu choice = null;
		scan = new Scanner(System.in);

		while (choice != UserMenu.QUIT) {
			System.out.println("************CONTACT BOOK*******************");
			System.out.println("CHOICE\tMENU");
			System.out.println("===========================================");
			for (UserMenu menuItem : UserMenu.values()) {
				System.out.println(menuItem.ordinal() + "\t" + menuItem.name());
			}

			System.out.println("Enter choice: ");
			int ordinal = scan.nextInt();
			if (ordinal < 0 || ordinal > UserMenu.QUIT.ordinal()) {
				System.err.println("Invalid choice");
				continue;
			}
			choice = UserMenu.values()[ordinal];
			switch (choice) {
			case ADD:
				doAdd();
				break;
			case SEARCH:
				doSearch();
				break;
			case LIST:
				doList();
				break;
			case EDIT:
				doEdit();
				break;
			case DELETE:
				doDelete();
				break;
			case QUIT:
				System.out.println("Thanks for interacting saving your info");
				break;
			}

		}
		scan.close();

	}

	public static void doAdd() {
		Contact contact = new Contact();
		System.out.println("Enter the first name");
		contact.setFirstName(scan.next());
		System.out.println("Enter the Middle name");
		contact.setMidName(scan.next());
		System.out.println("Enter the Last name");
		contact.setLastName(scan.next());
		System.out.println("Enter the Gender("
				+ Arrays.toString(Gender.values()) + ")");

		contact.setGender(Gender.valueOf(scan.next()));

		System.out.println("Enter mobile #1");
		contact.setMobileNumber1(scan.next());
		System.out.println("Enter mobile #2");
		contact.setMobileNumber2(scan.next());
		System.out.println("Enter official email id");
		contact.setOfficialEmail(scan.next());
		System.out.println("Enter home email id");
		contact.setHomeEmail(scan.next());
		System.out.println("Enter the Category("
				+ Arrays.toString(Category.values()) + ")");

		contact.setCategory(Category.valueOf(scan.next().toUpperCase()));

		System.out.println("Enter Oraganization");
		contact.setOrganization(scan.next());
		System.out.println("Enter Designation");
		contact.setDesignation(scan.next());

		try {
			boolean isSuccessful = service.add(contact);
			if (isSuccessful)
				System.out.println("contact sucessfully addded!");
			else
				System.out.println("contact could not be added!");
		} catch (ContactException exp) {
			System.err.println(exp.getMessage());
		}

	}

	public static void doList() {
		try {
			List<Contact> contacts = service.getAll();
			for (Contact contact : contacts) {
				System.out.println(contact);
			}
		} catch (ContactException exp) {
			System.err.println(exp.getMessage());
		}
	}

	public static void doSearch() {
		System.out.println("Enter contact Id: ");
		int contId = scan.nextInt();
		try {
			Contact contact = service.get(contId);
			if (contact == null) {
				System.out.println("Contact not found!");

			} else {
				System.out.println(contact);
			}
		} catch (ContactException exp) {
			System.err.println(exp.getMessage());
		}
	}

	public static void doEdit() {
		System.out.println("haha we fooled you");
	}

	public static void doDelete() {
		try {
			System.out.println("Enter contactId");
			int contId = scan.nextInt();
			Contact contact = service.get(contId);
			if (contact == null) {
				System.out.println("Contact not found!");

			} else {
				boolean isSuccessful = service.remove(contact.getContId());
				if (isSuccessful)
					System.out.println("Contact deleted!");
				else
					System.out.println("contact could not be deleted!");
			}

		} catch (ContactException exp) {
			System.err.println(exp.getMessage());
		}
	}
}
