package com.cg.ca.dao;

import java.util.List;

import com.cg.ca.dto.Contact;
import com.cg.ca.exception.ContactException;

public interface IContactDao {
	public boolean add(Contact contact) throws ContactException;
	public boolean remove(int contId) throws ContactException;
	public boolean update(Contact contact)throws ContactException;
	public Contact get(int contId)throws ContactException;
	public List<Contact> getAll() throws ContactException;
}
