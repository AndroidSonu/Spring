package com.cg.ca.dao;

public interface IQueryMapper {
		public static final String INSERT_CONT_QRY=
				"INSERT INTO contacts(contid,firstname,midname,lastname,gender,mobilenumber1,mobilenumber2,officialemail,homeemail,category,organization,designation)VALUES(contidseq.nextval,?,?,?,?,?,?,?,?,?,?,?)";
		public static final String UPDATE_CONT_QRY=
				"UPDATE contacts set firstname=?,midname=?,lastname=?,gender=?,mobilenumber1=?,mobilenumber2=?,officialemail=?homeemail=?,category=?,organization=?,designation=? where contid=?";
		public static final String DELETE_CONT_QRY=
				"delete from contacts where contid=?";
		public static final String SELECT_CONT_BY_ID_QRY=
				"select contid,firstname,midname,lastname,gender,mobilenumber1,mobilenumber2,officialemail,homeemail,category,organization,designation from contacts where contid=?";
		public static final String SELECT_ALL_CONT_QRY=
				"select contid,firstname,midname,lastname,gender,mobilenumber1,mobilenumber2,officialemail,homeemail,category,organization,designation from contacts";
}
