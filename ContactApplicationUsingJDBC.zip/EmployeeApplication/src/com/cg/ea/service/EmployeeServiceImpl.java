package com.cg.ea.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ea.dto.EmployeeApp;
import com.cg.ea.exception.EmployeeException;

public class EmployeeServiceImpl {
	private IEmployeeService ies=null;
	private List<String> validateErrors;
	
	public EmployeeServiceImpl() throws EmployeeException{
		ies=new IEmployeeDaoImpl();
	}
	
	public boolean isValidEmployeeId(int empId){
		return empId>0?true:false;
	}
	
	public boolean isValidFirstName(String name){
		Pattern pattern=Pattern.compile("[A-z]{1}[a-zA-Z]{25}");
		Matcher namematcher=pattern.matcher(name);
		return namematcher.matches();
		
	}
	
	public boolean isValidName(String name){
		Pattern pattern=Pattern.compile("[a-zA-Z\\s]{1,25}");
		Matcher namematcher=pattern.matcher(name);
		return namematcher.matches();
	}
	public boolean isValidMobile(String name){
		Pattern mobilePattern=Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher mobilematcher=mobilePattern.matcher(name);
		return mobilematcher.matches();
	}
	public boolean isValidEmailId(String name){
		Pattern emailPattern=Pattern.compile("[a-z]*[1-9]*@[a-z]*.{1}[a-z]*");
		Matcher emailMatcher=emailPattern.matcher(name);
		return emailMatcher.matches();
	}
	
	
	public boolean isValidEmployee(EmployeeApp employee){
		validateErrors=new ArrayList<>();
		if(employee!=null){
			if(!isValidFirstName(employee.getFirstName())){
				validateErrors.add("Please provide a valid FirstName");
			}
			
		}
		return validateErrors.size()==0 ?true:false;
	}
	

	
}
