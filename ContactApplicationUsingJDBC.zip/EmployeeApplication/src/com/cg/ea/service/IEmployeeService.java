package com.cg.ea.service;

import java.util.List;

import com.cg.ea.dto.EmployeeApp;
import com.cg.ea.exception.EmployeeException;

public interface IEmployeeService {
	public boolean add(EmployeeApp employee) throws EmployeeException;
	public boolean remove(int empId) throws EmployeeException;
	public boolean update(EmployeeApp employee) throws EmployeeException;
	public EmployeeApp get(int empId) throws EmployeeException;
	public List<EmployeeApp> getAll() throws EmployeeException;
}
