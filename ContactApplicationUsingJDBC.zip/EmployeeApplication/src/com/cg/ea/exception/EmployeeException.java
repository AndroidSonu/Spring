package com.cg.ea.exception;

public class EmployeeException extends Exception {
	public EmployeeException(String message){
		System.out.println(message);
	}
}
