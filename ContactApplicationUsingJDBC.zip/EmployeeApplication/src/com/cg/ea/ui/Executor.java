package com.cg.ea.ui;

public class Executor {

	public static void main(String[] args) {
		
	}

}
