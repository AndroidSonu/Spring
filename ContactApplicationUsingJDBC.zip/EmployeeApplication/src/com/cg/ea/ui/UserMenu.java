package com.cg.ea.ui;

public enum UserMenu {
	ADD,SEARCH,LIST,EDIT,DELETE,QUIT;
}
