package com.cg.ea.dto;

public enum Gender {
	MALE,FEMALE;
}
