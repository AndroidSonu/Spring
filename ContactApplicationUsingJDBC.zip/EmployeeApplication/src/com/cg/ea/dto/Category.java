package com.cg.ea.dto;

public enum Category {
	FAMILY,FRIENDS,ACQUAINTANCE,WORK,OTHERS;
}
