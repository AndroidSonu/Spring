package com.cg.map.dao;

public interface IQueryMapper {

	public static final String INSERT_MOB_QRY =
			"INSERT INTO mobiles(mobileId,customerName,price,quantity) VALUES(?,?,?,?)";
	
	public static final String UPDATE_MOB_QRY = 
			"UPDATE mobiles SET name=?,price=?,quantity=?";
	
	public static final String DELETE_MOB_QRY = 
			"DELETE FROM mobiles WHERE mobileid=? ";
	
	public static final String SELECT_MOB_BY_ID_QRY = 
			"SELECT mobileid,name,price,quantity FROM mobiles WHERE price between ? and ?";
	
	public static final String SELECT_MOB_EMP_QRY = 
			"SELECT mobileid,name,price,quantity FROM mobiles";
	
	public static final String INSERT_PUR_QRY =
			"INSERT INTO purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) VALUES(purchaseIdSeq.NEXTVAL,?,?,?,?,?)";
	
	
}
