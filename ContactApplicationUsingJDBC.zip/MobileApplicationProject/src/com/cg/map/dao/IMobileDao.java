package com.cg.map.dao;

import java.util.List;

import com.cg.map.dto.Mobile;
import com.cg.map.exception.MobileException;

public interface IMobileDao {
	public boolean add(Mobile mobile)throws MobileException;
	public boolean update(Mobile mobile) throws MobileException;
	public boolean remove(int mobileId) throws MobileException;
	public Mobile get(int price1,int price2) throws MobileException;
	//public Mobile get(int mobileId) throws MobileException;
	public List<Mobile>getAll() throws MobileException;
	
}
