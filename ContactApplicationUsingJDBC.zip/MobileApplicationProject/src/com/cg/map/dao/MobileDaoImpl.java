package com.cg.map.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;






import com.cg.map.dto.Mobile;
import com.cg.map.exception.MobileException;
import com.cg.map.util.ConnectionProvider;

public class MobileDaoImpl implements IMobileDao{
		private Logger classLogger;
		private ConnectionProvider conn;
	
		public MobileDaoImpl() throws MobileException{
			classLogger=Logger.getLogger(MobileDaoImpl.class);
			try{
				conn=ConnectionProvider.getInstance("resources/jdbc.properties");	
			} catch (ClassNotFoundException | IOException exp) {
				classLogger.error(exp);
				throw new MobileException("Data Access Initiation Failed!");
			}
			
		}
		
		public Mobile mapRow(ResultSet row ) throws MobileException{
			Mobile mobile=new Mobile();
			try {
				mobile.setMobileId(row.getInt("mobileId"));
				mobile.setCustomerName(row.getString("customerName"));
				mobile.setPrice(row.getInt("price"));
				mobile.setQuantity(row.getInt("quantity"));
				
			} catch (SQLException e) {
				classLogger.error(e);
				throw new MobileException("Data is not initilised");
			}
			
			return mobile;
		}
		
		

		@Override
		public boolean add(Mobile mobile) throws MobileException {
			boolean result=false;
			if(mobile!=null){
				try(Connection con=conn.getConnection();
					PreparedStatement pstInsert=con.prepareStatement(IQueryMapper.INSERT_MOB_QRY)){
					classLogger.debug(mobile+"being added!");
					pstInsert.setInt(1,mobile.getMobileId());
					pstInsert.setString(2,mobile.getCustomerName());
					pstInsert.setInt(3,mobile.getPrice());
					pstInsert.setInt(4,mobile.getQuantity());
					classLogger.debug("5 rows added!");
					int count = pstInsert.executeUpdate();
					if (count > 0)
						result = true;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					classLogger.error(e);
					throw new MobileException("Failed to add record!");
				}
			}
			return result;
		}

		@Override
		public boolean update(Mobile mobile) throws MobileException {
			// TODO Auto-generated method stub
			boolean result=false;
			if(mobile!=null){
			try(Connection con=conn.getConnection();
					PreparedStatement pstUpdate= con.prepareStatement(IQueryMapper.UPDATE_MOB_QRY)){
						classLogger.debug(mobile+"being update!");
						pstUpdate.setInt(1,mobile.getMobileId());
						pstUpdate.setString(2,mobile.getCustomerName());
						pstUpdate.setInt(3,mobile.getPrice());
						pstUpdate.setInt(4,mobile.getQuantity());
						classLogger.debug("5 updated added!");
						int count = pstUpdate.executeUpdate();
						if (count > 0)
							result = true;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						classLogger.error(e);
					}
				}
				return result;
		}

		@Override
		public boolean remove(int mobileId) throws MobileException {
			boolean result=false;
			try(Connection con=conn.getConnection();
					PreparedStatement pstDelete= con.prepareStatement(IQueryMapper.DELETE_MOB_QRY)){
			pstDelete.setInt(1, mobileId);
			int count=pstDelete.executeUpdate();
			if(count>0)
				return true;
				
		} catch (SQLException e) {
			classLogger.error(e);
		}
			return result;
		}

		@Override
		public Mobile get(int price1, int price2) throws MobileException {
			Mobile mobile = null;
			try (Connection con = conn.getConnection();
					PreparedStatement pstSelectById = con
							.prepareStatement(IQueryMapper.SELECT_MOB_BY_ID_QRY)) {
				pstSelectById.setInt(1, price1);
				pstSelectById.setInt(2, price2);
				ResultSet result = pstSelectById.executeQuery();
				if (result.next())
					mobile = mapRow(result);
			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new MobileException("Failed to get record!");
			}

			return mobile;
		}

		@Override
		public List<Mobile> getAll() throws MobileException {
			List<Mobile> mobileList = new ArrayList<>();
			try (Connection con = conn.getConnection();
					PreparedStatement pstSelectAll = con
							.prepareStatement(IQueryMapper.SELECT_MOB_EMP_QRY)) {

				ResultSet results = pstSelectAll.executeQuery();
				while (results.next()) {
					mobileList.add(mapRow(results));
				}
			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new MobileException("Failed to Retrieve records!");
			}

			return mobileList;
		}
		
}
