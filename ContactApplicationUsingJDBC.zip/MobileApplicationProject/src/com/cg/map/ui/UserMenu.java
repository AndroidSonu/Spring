package com.cg.map.ui;

public enum UserMenu {
	ADD,SEARCH,LIST,EDIT,DELETE,QUIT;
}
