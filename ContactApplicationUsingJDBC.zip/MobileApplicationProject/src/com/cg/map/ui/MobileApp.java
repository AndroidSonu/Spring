package com.cg.map.ui;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;





import com.cg.map.dto.Mobile;
import com.cg.map.exception.MobileException;
import com.cg.map.service.IMobileService;
import com.cg.map.service.MobileServiceImpl;

public class MobileApp {
	static IMobileService service;
	static Scanner scan;
	public static void main(String args[]){
		try {
			service=new MobileServiceImpl();
			System.out.println("service started");
		} catch (MobileException exp) {
			System.err.println(exp.getMessage());
			System.exit(0);
		}
		PropertyConfigurator.configure("resources/log4j.properties");
		UserMenu choice=null;
		scan=new Scanner(System.in);
		while(choice!=UserMenu.QUIT){
			System.out.println("**********************Employee Record*******************");
			System.out.println("CHOICE\tVALUES");
			System.out.println("=========================================================");
			for(UserMenu menuItem: UserMenu.values()){
				System.out.println(menuItem.ordinal() +"\t"+ menuItem.name());
			}
			
			System.out.println("Enter the choice");
			int ordinal=scan.nextInt();
			
			if (ordinal < 0 || ordinal > UserMenu.QUIT.ordinal()) {
				System.err.println("Invalid Choice...");
				continue;
			}
			
			choice=UserMenu.values()[ordinal];

			switch (choice) {
			case ADD:
				doAdd();
				break;
			case SEARCH:
				doSearch();
				break;
			case LIST:
				doList();
				break;
			case EDIT:
				doEdit();
				break;
			case DELETE:
				doDelete();
				break;
			case QUIT:
				System.out.println("Thank You!");
				break;
			}
		
		
		}
		scan.close();
		
	}
		public static void doAdd(){
			Mobile mobile=new Mobile();

			System.out.println("Enter mobile Name: ");
			mobile.setCustomerName(scan.next());
			
			System.out.println("Enter mobileid");
			mobile.setMobileId(scan.nextInt());

			System.out.println("Enter price");
			mobile.setPrice(scan.nextInt());
			
			System.out.println("Enter quantity");
			mobile.setQuantity(scan.nextInt());

			try {
				boolean isSuccessful = service.add(mobile);

				if (isSuccessful)
					System.out.println("Employee successfully added!");
				else
					System.out.println("Employee could not be added!");
			} catch (MobileException exp) {
				System.err.println(exp.getMessage());
			}

		}

		public static void doList() {
			try {
				List<Mobile> mobiles = service.getAll();
				for (Mobile employee : mobiles)
					System.out.println(employee);
			} catch (MobileException exp) {
				System.err.println(exp.getMessage());
			}
		}

		public static void doSearch() {
			System.out.println("Enter Employee Id: ");
			int price1 = scan.nextInt();
			int price2=scan.nextInt();
			try {
				Mobile mobile = service.get(price1,price2);
				if (mobile == null) {
					System.out.println("Employee Not Found!");
				} else
					System.out.println(mobile);
			} catch (MobileException exp) {
				System.err.println(exp.getMessage());
			}
		}

		public static void doEdit() {
			System.out.println("Sorry! This feature is not available yet!");
		}

		public static void doDelete() {
			try {
				System.out.println("Enter EmployeeId: ");
				int price1 = scan.nextInt();
				int price2 = scan.nextInt();
				Mobile mobile = service.get(price1,price2);
				if (mobile == null) {
					System.out.println("Employee Not Found!");
				} else {
					boolean isSuccessful = service.remove(mobile.getMobileId());
					if (isSuccessful)
						System.out.println("Employee deleted!");
					else
						System.out.println("Employee could not be deleted!");
				}
			} catch (MobileException exp) {
				System.err.println(exp.getMessage());
			}
		}
	
}
