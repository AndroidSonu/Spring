package com.cg.map.dto;

public class Mobile {
	
	private int mobileId;
	private String customerName;
	private int price;
	private int quantity;
	
	
	public Mobile(){
		
	}
	public Mobile( int mobileId,String customerName,int price, int quantity) {
		super();
		this.customerName = customerName;
		this.mobileId = mobileId;
		this.price = price;
		this.quantity = quantity;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", customerName="
				+ customerName + ", price=" + price + ", quantity=" + quantity
				+ "]";
	}
	
	
}
