package com.cg.map.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.map.dao.IMobileDao;
import com.cg.map.dao.MobileDaoImpl;
import com.cg.map.dto.Mobile;
import com.cg.map.exception.MobileException;

public class MobileServiceImpl implements IMobileService {
	IMobileDao dao=null;
	private List<String> validationErrors;
	
	public MobileServiceImpl() throws MobileException{
		dao=new MobileDaoImpl();
		
	}
	
	public boolean isValidMobileId(int mobileId){
		return mobileId>0?true:false;
	}
	
	public boolean isValidMobileName(String name) {
		Pattern namePattern = Pattern.compile("[A-Z]{1}[a-zA-Z\\s]{3,25}");
		Matcher nameMatcher = namePattern.matcher(name);
		return nameMatcher.matches();
	}
	public boolean isValidNumber(String name){
		Pattern mobilePattern = Pattern.compile("[1-9]{1}[0-9]{3}");
		Matcher nameMatcher = mobilePattern.matcher(name);
		return nameMatcher.matches();
	}
	public boolean isValidQuantity(String name){
		Pattern mobilePattern = Pattern.compile("[1-9]{1,}");
		Matcher nameMatcher = mobilePattern.matcher(name);
		return nameMatcher.matches();
	}
	
	public boolean isValidMobile(Mobile mobile) {
		validationErrors = new ArrayList<>();
		if (mobile != null) {
			if (!isValidMobileName((mobile.getCustomerName()))) {
				validationErrors
						.add("First name must start with capital letter");
			}
			if (!isValidNumber(String.valueOf(mobile.getMobileId()))) {
				validationErrors.add(" Number is not valid digits");
			}
			
			if (!isValidQuantity(String.valueOf(mobile.getQuantity()))) {
				validationErrors.add(" Quantity is not valid");
			}

		}
		return validationErrors.size() == 0 ? true : false;
	}
	
	
	
	@Override
	public boolean add(Mobile mobile) throws MobileException {
		
		boolean result = false;
		if (isValidMobile(mobile)) {
			result = dao.add(mobile);
		} else {
			throw new MobileException("Can't have Invalid Employee!"
					+ validationErrors);
		}

		return result;
	}

	@Override
	public boolean update(Mobile mobile) throws MobileException {
		boolean result = false;
		if (isValidMobile(mobile)) {
			result = dao.update(mobile);
		} else {
			throw new MobileException("Can't have Invalid Employee!"
					+ validationErrors);
		}

		return result;
	
	}

	@Override
	public boolean remove(int mobileId) throws MobileException {
		return dao.remove(mobileId);
	}

	@Override
	public Mobile get(int price1, int price2) throws MobileException {
		return dao.get(price1,price2);
	}

	@Override
	public List<Mobile> getAll() throws MobileException {
		return dao.getAll();
	}

}
