package com.cg.map.service;

import java.util.List;

import com.cg.map.dto.Mobile;
import com.cg.map.exception.MobileException;

public interface IMobileService {
	public boolean add(Mobile mobile)throws MobileException;
	public boolean update(Mobile mobile) throws MobileException;
	public boolean remove(int mobileId) throws MobileException;
	public Mobile get(int price1,int price2) throws MobileException;
	public List<Mobile>getAll() throws MobileException;
}
