DROP TABLE Candidate_Detail;

CREATE TABLE Candidate_Detail(
	applyId NUMBER PRIMARY KEY,
	firstName VARCHAR2(20),
	lastName VARCHAR2(10),
	contactNo NUMBER(10),
	email VARCHAR2(30),
	aggregate NUMBER(5,2),
	stream VARCHAR2(25)
);


CREATE SEQUENCE apply_id_seq
MINVALUE 1000
MAXVALUE 99999
START WITH 1001
INCREMENT BY 1
NOCACHE;