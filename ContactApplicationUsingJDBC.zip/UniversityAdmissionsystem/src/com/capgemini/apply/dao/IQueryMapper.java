package com.capgemini.apply.dao;

public interface IQueryMapper {

	public static final String INSERT_INTO_CONTACT_DETAIL = " INSERT INTO Candidate_Detail(applyId,firstName,lastName,contactNo,email,aggregate,stream) VALUES (apply_id_seq.nextval,?,?,?,?,?,?)";
	public static final String GET_RECORD_BY_APPLYID = "SELECT applyId,firstName,lastName,contactNo,email,aggregate,stream FROM Candidate_Detail WHERE applyId = ?  ";
	public static final String GET_ALL_RECORDS = "SELECT empId,empName,empPassword,gender,mobileNumber,emailId,designation FROM Candidate_Detail";
	public static final String GET_CURRVAL = "SELECT apply_id_seq.currval FROM DUAL";

}
