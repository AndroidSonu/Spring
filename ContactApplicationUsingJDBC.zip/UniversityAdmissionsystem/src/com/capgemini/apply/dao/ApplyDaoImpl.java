package com.capgemini.apply.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;
import com.capgemini.contact.util.ConnectionProvider;





 

public class ApplyDaoImpl  implements ApplyDao{
	private Logger classLogger;
	private ConnectionProvider connProvider;
	
	
	public ApplyDaoImpl() throws ApplicantException{
		classLogger = Logger.getLogger(ApplyDaoImpl.class);
		try{
			connProvider = ConnectionProvider
				.getInstance("resources/dbConfig.properties");
		}catch (ClassNotFoundException | IOException exp) {
			classLogger.error(exp);
			throw new ApplicantException("Data Access Initiation Failed");
	}
	
 }


	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException {
		int curr_id=-1;
		
		if (applicant != null) {

			try (Connection conn = connProvider.getConnection();
					PreparedStatement infoAdd = conn
							.prepareStatement(IQueryMapper.INSERT_INTO_CONTACT_DETAIL);
							PreparedStatement prepCurrId = conn.prepareStatement(IQueryMapper.GET_CURRVAL)) {
					classLogger.debug(applicant + "being added ");
					infoAdd.setString(1,applicant.getFname());
					infoAdd.setString(2,applicant.getlName());
					infoAdd.setLong(3,applicant.getContactNo());
					infoAdd.setString(4,applicant.getEmail());
					infoAdd.setFloat(5,applicant.getAggregate());
					infoAdd.setString(6,applicant.getStream());
					
					int count=infoAdd.executeUpdate();
					
					if (count > 0) {
						ResultSet results = prepCurrId.executeQuery();
						if (results.next()) {
							curr_id = results.getInt(1);
							conn.commit();
							conn.setAutoCommit(true);
						}
					}
					
					} catch (SQLException exp) {
						classLogger.error(exp);
						throw new ApplicantException("Failed to Add Student!");
					
			}
			
			
			}
			
			return curr_id;
	}


	@Override
	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException {

		ApplicantBean applicant = null;
		try (Connection conn = connProvider.getConnection();
				PreparedStatement applicantGetId = conn
						.prepareStatement(IQueryMapper.GET_RECORD_BY_APPLYID)){
			applicantGetId.setLong(1, applicantID);
			
			ResultSet result = applicantGetId.executeQuery();
			
			if(result.next()){
				applicant = mapRow(result);
			}
		}catch (SQLException exp) {
			classLogger.error(exp);
			throw new ApplicantException("Failed to retreive Employee");

		}
		return applicant;
	}
	
	public ApplicantBean mapRow(ResultSet result) throws ApplicantException{
		ApplicantBean applicant = new ApplicantBean();
		try {
			applicant.setApplyId(result.getLong("applyId"));
			applicant.setFname(result.getString("firstName"));
			applicant.setlName(result.getString("lastName"));
			applicant.setContactNo(result.getLong("contactNo"));
			applicant.setEmail(result.getString("email"));
			applicant.setAggregate(result.getFloat("aggregate"));
			applicant.setStream(result.getString("stream"));
		
		
	}
		catch (SQLException exp) {
			classLogger.error(exp);
			throw new ApplicantException("Could not Retrive Data");
		}
		return applicant;
	}
	
}
