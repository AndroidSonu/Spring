package com.capgemini.contact.bean;

public class ApplicantBean {
	private long applyId;
	private String fname;
	private String lName;
	private String email;
	private long contactNo;
	private String stream;
	private float aggregate;
	
	public ApplicantBean(){
		
	}

	public ApplicantBean(long applyId, String fname, String lName,
			String email, long contactNo, String stream, float aggregate) {
		super();
		this.applyId = applyId;
		this.fname = fname;
		this.lName = lName;
		this.email = email;
		this.contactNo = contactNo;
		this.stream = stream;
		this.aggregate = aggregate;
	}

	public long getApplyId() {
		return applyId;
	}

	public void setApplyId(long applyId) {
		this.applyId = applyId;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getContactNo() {
		return contactNo;
	}

	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public float getAggregate() {
		return aggregate;
	}

	public void setAggregate(float aggregate) {
		this.aggregate = aggregate;
	}

	@Override
	public String toString() {
		return "ApplicantBean [applyId=" + applyId + ", fname=" + fname
				+ ", lName=" + lName + ", email=" + email + ", contactNo="
				+ contactNo + ", stream=" + stream + ", aggregate=" + aggregate
				+ "]";
	}
	
	
	
}
