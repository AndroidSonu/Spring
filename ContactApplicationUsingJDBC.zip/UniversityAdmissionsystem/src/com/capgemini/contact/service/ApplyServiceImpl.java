package com.capgemini.contact.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.apply.dao.ApplyDao;
import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;


public class ApplyServiceImpl implements ApplyService{
	
	private ApplyDao dao = null;
	private List<String> validationErrors;
	public ApplyServiceImpl() throws ApplicantException{
		dao = new ApplyDaoImpl();
	}
	
	public boolean isValidApplicantId(int applyId){
		return applyId > 1000 ? true : false;
		
	}
	public boolean validateAggregateNumber(float aggregate) {
		return (aggregate > 0.00 && aggregate < 100.00) ? true : false;
 
	}
	
	public boolean validateFirstName(String fName){
		
		Pattern namePattern = Pattern.compile("[A-Z]{1}[a-zA-Z//s]{3,25}");
		Matcher nameMatcher = namePattern.matcher(fName);
		return nameMatcher.matches();
	}
	
	public boolean validateLastName(String lName){
		
		Pattern namePattern = Pattern.compile("[A-Z]{1}[a-z//s]{3,25}");
		Matcher nameMatcher = namePattern.matcher(lName);
		return nameMatcher.matches();
	}
	
	public boolean validateContactNo(long contactNo){
		Pattern mobileNumberPattern = Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher mobileMatcher = mobileNumberPattern.matcher(Long.toString(contactNo));
		return mobileMatcher.matches();
	}
	
	public boolean ValidateEmail(String pLocation)
	{
		Pattern emailPattern = Pattern
				.compile("[a-z]+([._]|[a-z]|[0-9])+@[a-z]+.[a-z]+(.[a-z]+)?");
		Matcher emailMatcher = emailPattern.matcher(pLocation);
		return emailMatcher.matches();
	}
	
	public boolean validateAggregate(float aggregate) {
		Pattern aggregatePattern = Pattern
				.compile("[1-9]{1}[0-9]{1,2}.[0-9]{1,2}");
		Matcher aggregateMatcher = aggregatePattern.matcher(Float
				.toString(aggregate));
		return aggregateMatcher.matches();
 
	}
	
	public boolean validateStream(String stream){
		Pattern stramPattern = Pattern
				.compile("[A-Z]{1}*[a-z][//s]{1}[A-Z]{1}*[a-z]");
		Matcher aggregateMatcher =stramPattern.matcher(stream);
		return aggregateMatcher.matches();
	}
	

	
	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException {
		int result = -1;
		if (isValidApplicant(applicant)) {
			result = dao.addApplicantDetails(applicant);
		} else {
			throw new ApplicantException("Can't have Invalid applicant!"
					+ validationErrors);
		}
		return result;
	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException {
		return dao.getApplicantDetails(applicantID);
	}

	@Override
	public boolean isValidApplicant(ApplicantBean applicant)
			throws ApplicantException {
		validationErrors = new ArrayList<>();

		if (applicant != null) {
			
			if (!validateFirstName(applicant.getFname())) {
				validationErrors
						.add("First name must start with UpperCase Letters and atleast 4 characters");
			}
			
			if (!validateLastName(applicant.getlName())) {
				validationErrors
						.add("Last name must start with UpperCase Letters and atleast 4 characters");
			}
			
			if (!validateContactNo(applicant.getContactNo())) {
				validationErrors
						.add("Contact No should be atleast 10 digits not starting with 0");
			}
			/*
			if (!validateFirstName(applicant.getStream())) {
				validationErrors
						.add("Stream should be either ComputerScience or Information Technology");
			}*/
			
			if (!ValidateEmail(applicant.getEmail())) {
				validationErrors
						.add("Enter a valid Email Id");
			}
			
			if(!(applicant.getStream().equalsIgnoreCase("Computer Science"))||!(applicant.getStream().equalsIgnoreCase("Information Technology")))
			{
				validationErrors.add("Stream must be either Computer Science or Information Technology");

			}
			
			/*if (!validateStream(applicant.getStream())) {
				validationErrors
						.add("Enter a valid Stram name");
			}*/
			
		}
		
		return validationErrors.size() == 0 ? true : false;
	}
	


}
