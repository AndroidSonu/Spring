package com.capgemini.contact.service;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;

public interface ApplyService {
	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException;
	public ApplicantBean getApplicantDetails(long applicantID) throws ApplicantException;
	public boolean isValidApplicant(ApplicantBean applicant) throws ApplicantException;
}
