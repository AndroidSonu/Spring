package com.capgemini.contact.ui;

public enum UserMenu {
	QUIT,ADD,SEARCH;
}

