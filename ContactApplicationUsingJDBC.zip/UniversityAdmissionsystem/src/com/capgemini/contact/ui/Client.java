package com.capgemini.contact.ui;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;
import com.capgemini.contact.service.ApplyService;
import com.capgemini.contact.service.ApplyServiceImpl;




public class Client {
	static ApplyService service;
	static Scanner scan;
	
	public static void main(String[] args) {
		
		try {
			service = new ApplyServiceImpl();
			System.out.println("Service Started!");
		} catch (ApplicantException exp) {

			System.err.println(exp.getMessage());
			System.exit(0);
		}
		
		PropertyConfigurator.configure("resources/log4j.properties");
		
		UserMenu choice = null;
		scan = new Scanner(System.in);
		
		while (choice != UserMenu.QUIT) {
			System.out.println("**********  EMPLOYEES DETAILS  **************");
			System.out.println("CHOICE\t MENU");
			System.out.println("========================================");
			for (UserMenu menuItem : UserMenu.values()) {
				System.out.println(menuItem.ordinal() + "\t" + menuItem.name());
			}

			System.out.println("Enter Choice: ");
			int ordinal = scan.nextInt();

			if (ordinal < 0 || ordinal > UserMenu.SEARCH.ordinal()) {
				System.err.println("Invalid Choice");
				continue;
			}
			
			choice = UserMenu.values()[ordinal];

			switch (choice) {
			case ADD:
				doAdd();
				break;

			case SEARCH:
				doSearch();
				break;
			
			case QUIT:
				System.out.println("Thank You! for applying");
				break;

			}
		
		}
		scan.close();
	}  
	
	public static void doAdd() {
		ApplicantBean applicant = new ApplicantBean();
		System.out.print("Enter First Name : ");
		applicant.setFname(scan.next());
		System.out.print("Enter Last Name : ");
		applicant.setlName(scan.next());
		System.out.print("Enter Contact Number : ");
		applicant.setContactNo(scan.nextLong());
		System.out.print("Enter email : ");
		
		applicant.setEmail(scan.next());
		
		System.out.print("Enter Stream : ");
		 Scanner scaner = new Scanner(System.in);
	        String name="";

	        name+=scaner.nextLine();
	        scan.close();
		applicant.setStream(name);
		System.out.print("Enter Aggregate in qualifying exam : ");
		applicant.setAggregate(scan.nextFloat());

		try {
			int curr_id = service.addApplicantDetails(applicant);
			if (curr_id > 0 ) {
				System.out.println("Your Unique Id is " + curr_id + " we will contact you shortly");
			}else {
				System.out.println("Student could not be added");
			}
		} catch (ApplicantException exp) {
			System.err.println(exp.getMessage());
		}
	}
	
	public static void doSearch() {

		System.out.println("Enter the Applicant Id .: ");
		int applyId = scan.nextInt();

		try {
			ApplicantBean employee = service.getApplicantDetails(applyId);
			if (employee == null) {
				System.out.println("Employee not Found");
			} else {
				System.out.println(employee);
			}
		} catch (ApplicantException exp) {
			System.err.println(exp.getMessage());
		}
	}	
}
