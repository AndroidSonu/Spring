package com.capgemini.contact.exception;

public class ApplicantException extends Exception {
	public ApplicantException(String message){
		super(message);
	}

}
