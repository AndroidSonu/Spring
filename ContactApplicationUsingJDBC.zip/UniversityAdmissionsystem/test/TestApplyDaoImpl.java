import static org.junit.Assert.*;

import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.apply.dao.ApplyDao;
import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;



public class TestApplyDaoImpl {
	
	ApplyDao dao=null;
	@Before
	public void setUp() throws Exception {
		PropertyConfigurator.configure("resources/adbe.properties");
		dao=new ApplyDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void testAddNullEmployee(){
		try{
			ApplicantBean input = null;
			int  expected = -1;
			int actual = dao.addApplicantDetails(input);
			assertTrue(expected == actual);
		}catch (ApplicantException e){
			fail("Did not expect exception");
		}
	}

	@Test
	public void testAddNotNullEmployee() throws Exception{
	
			ApplicantBean input = new ApplicantBean();
			input.setFname("Pandas");
			input .setlName("Karmar");
			input.setContactNo(7894561235l);
			input.setEmail("panda@gmail.com");
			input.setStream("Computer Science");
			input.setAggregate(98.56f);
		
	}
	@Test
	@Ignore
	public void testApplyDaoImpl() {
		fail("Not yet implemented");
	}

	@Test
	@Ignore
	public void testAddApplicantDetails() {
		fail("Not yet implemented");
	}

	@Test
	@Ignore
	public void testGetApplicantDetails() {
		fail("Not yet implemented");
	}

	@Test
	@Ignore
	public void testMapRow() {
		fail("Not yet implemented");
	}

}
