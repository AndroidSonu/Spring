package com.cg.ws.controller;

import java.net.URL;

public class CurrencyConverter {

	public static void main(String[] args) throws Exception{
		
		URL url=new URL("http://www.webservicex.net/CurrencyConvertor.asmx");
		
	
		
	}
}
