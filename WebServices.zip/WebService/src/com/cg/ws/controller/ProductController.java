package com.cg.ws.controller;



import javax.jws.WebService;

import com.cg.ws.service.ProductService;
import com.cg.ws.service.ProductServiceImpl;


@WebService
public class ProductController {
	ProductService service;
	
	public ProductController(){
		service=new ProductServiceImpl();
	}
	
	public float getPrice(String name){
		
		return 0;
	}
	
	
}
