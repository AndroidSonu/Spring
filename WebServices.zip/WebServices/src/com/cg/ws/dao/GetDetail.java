package com.cg.ws.dao;

import com.cg.ws.entities.Product;

public interface GetDetail {
	public float  getPrice(String name);
}
