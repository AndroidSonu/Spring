package com.cg.ws.dao;

import java.util.List;

import com.cg.ws.db.ProductDB;
import com.cg.ws.entities.Product;

public class GetDetailImpl implements GetDetail{
	static List<Product> getprice=ProductDB.loadList();

	@Override
	public float getPrice(String name) {
		float price=0.0f;
		for(Product pro:getprice){
			if(pro.getProdName()==name){
				pro.getProdPrice();
			}
			
		}
		return price;
	
	}

}
