package com.cg.ws.controller;



import java.util.Scanner;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import com.cg.ws.service.ProductService;
import com.cg.ws.service.ProductServiceImpl;


@Path("/test")
public class ProductController {
	ProductService service;
	
	public ProductController(){
		service=new ProductServiceImpl();
	}
	
	@GET
	@Path("/price")
	public void getPrice(){
		
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
	 float price=service.getPrice(name);
	 if(price==0){
		 System.out.println("Product does not exists!!!");
	 }
	 else
	 System.out.println("product price of the product   "+price);
	}
	
	
}
