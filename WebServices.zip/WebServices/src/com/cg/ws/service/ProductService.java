package com.cg.ws.service;

public interface ProductService {
	public float  getPrice(String name);
}
