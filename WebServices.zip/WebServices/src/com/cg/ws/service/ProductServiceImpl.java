package com.cg.ws.service;

import com.cg.ws.dao.GetDetail;
import com.cg.ws.dao.GetDetailImpl;

public class ProductServiceImpl implements ProductService {

	GetDetail dao=null;
	public ProductServiceImpl(){
		dao=new GetDetailImpl();
	}
	@Override
	public float getPrice(String name) {
		return dao.getPrice(name);
	}
	
}
