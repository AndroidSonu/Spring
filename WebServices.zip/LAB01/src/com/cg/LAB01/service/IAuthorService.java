/**
 * 
 */
package com.cg.LAB01.service;

import java.util.List;

import com.cg.LAB01.entities.Author;

/**
 * @author anurag
 *
 */
public interface IAuthorService {
	public abstract Author getAuthorById(int id);

	public List<Author> getAll();
	
	public abstract void addAuthor(Author author);

	public abstract void deleteAuthor(Author author);

	public abstract void updateAuthor(Author author);
}
