/**
 * 
 */
package com.cg.LAB01.service;

import java.util.List;

import com.cg.LAB01.dao.AuthorDaoImpl;
import com.cg.LAB01.dao.IAuthorDao;
import com.cg.LAB01.entities.Author;

/**
 * @author anurag
 *
 */
public class AuthorServiceImpl implements IAuthorService{
	private IAuthorDao dao;
	
	public AuthorServiceImpl(){
		dao = new AuthorDaoImpl();
	}

	@Override
	public Author getAuthorById(int id) {
		Author author = dao.getAuthorById(id);
		return author;
	}

	@Override
	public void addAuthor(Author author) {
		dao.beginTransaction();
		dao.addAuthor(author);
		dao.commitTransaction();
	}

	@Override
	public void deleteAuthor(Author author) {
		dao.beginTransaction();
		dao.deleteAuthor(author);
		dao.commitTransaction();
	}

	@Override
	public void updateAuthor(Author author) {
		dao.beginTransaction();
		dao.updateAuthor(author);
		dao.commitTransaction();
	}

	@Override
	public List<Author> getAll() {
		return dao.getAll();
	}

}
