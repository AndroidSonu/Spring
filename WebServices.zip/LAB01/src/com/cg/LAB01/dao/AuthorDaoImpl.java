/**
 * 
 */
package com.cg.LAB01.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.LAB01.entities.Author;

/**
 * @author anurag
 *
 */
public class AuthorDaoImpl implements IAuthorDao{

	private EntityManager entityManager;

	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	
	@Override
	public Author getAuthorById(int id) {
		Author author= entityManager.find(Author.class, id);
		return author;
	}

	@Override
	public void addAuthor(Author author) {
		entityManager.persist(author);
	}

	@Override
	public void deleteAuthor(Author author) {
		entityManager.remove(author);
	}

	@Override
	public void updateAuthor(Author author) {
		entityManager.merge(author);
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}


	@Override
	public List<Author> getAll() {
		return entityManager.createQuery("from Author",Author.class).getResultList();
	}
	
}
