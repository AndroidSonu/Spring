/**
 * 
 */
package com.cg.LAB01.dao;

import java.util.List;

import com.cg.LAB01.entities.Author;


/**
 * @author anurag
 *
 */
public interface IAuthorDao {
	public abstract Author getAuthorById(int id);

	public abstract void addAuthor(Author author);

	public abstract void deleteAuthor(Author author);

	public abstract void updateAuthor(Author author);
	
	public List<Author> getAll();

	public abstract void commitTransaction();

	public abstract void beginTransaction();
}
