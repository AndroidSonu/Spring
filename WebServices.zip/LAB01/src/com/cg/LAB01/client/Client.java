/**
 * 
 */
package com.cg.LAB01.client;

import java.util.Scanner;

import com.cg.LAB01.entities.Author;
import com.cg.LAB01.service.AuthorServiceImpl;
import com.cg.LAB01.service.IAuthorService;

/**
 * @author anurag
 *
 */
public class Client {

	public static void main(String[] args) {
		IAuthorService service = new AuthorServiceImpl();
		Author author = new Author();
		String confirm="";
		Scanner scan = new Scanner(System.in);
	do{
		
			System.out.println("Choose the Options Given Below");
			System.out.println("1 . Add Author");
			System.out.println("2 . Delete Author");
			System.out.println("3 . Update Author");
			System.out.println("4 . View All");
			System.out.println("5 . Exit");
			
		int choice=scan.nextInt();
		switch(choice)
		{
		case 1 : System.out.println("Enter the Author ID");
		         int id = scan.nextInt();
		         System.out.println("Enter the Author First Name");
		         String fname= scan.next();
		         System.out.println("Enter the Author Middle Name");
		         String mname= scan.next();
		         System.out.println("Enter the Author Last Name");
		         String lname= scan.next();
		         System.out.println("Enter the Phone Number");
		         long no= scan.nextLong();
		         
		         author.setAuthorId(id);
		         author.setFirstname(fname);
		         author.setMiddlename(mname);
		         author.setLastname(lname);
		         author.setPhoneNo(no);
		         service.addAuthor(author);
		         System.out.println("Record Added");
		         
		         break;
		case 2 : System.out.println("Enter the Author ID");
				 int did = scan.nextInt();
				 author = service.getAuthorById(did);
		         service.deleteAuthor(author);
		         System.out.println("Record Deleted");
		         break;
		case 3 : System.out.println("Enter the Author Id");
				 int ID = scan.nextInt();
				 author = service.getAuthorById(ID);
				 System.out.println("Enter First Name");
				 String firstname = scan.next();
				 author.setFirstname(firstname);
				 service.updateAuthor(author);
				 System.out.println("Record Updated");
				 break;
		case 4 : for(Author auth : service.getAll()){
					System.out.println(auth.getAuthorId()+" "+auth.getFirstname()+" "+auth.getMiddlename()+" "+auth.getLastname()+" "+auth.getPhoneNo());
		}
		break;
		case 5 : System.out.println("Thank You!");
				System.exit(0);
				break;
		}
		System.out.println("do you want to continue!!?Yes/No");
		confirm=scan.next();
		if(confirm.equalsIgnoreCase("No")){
			System.out.println("Thank You (<>)");
			System.exit(0);
		}
	}	while(confirm.equalsIgnoreCase("Yes"));
	}
	}


