package com.capgemini.hbms.ui;

public enum UserMenu {
	ADMIN, CUSTOMER, EXIT;
}
