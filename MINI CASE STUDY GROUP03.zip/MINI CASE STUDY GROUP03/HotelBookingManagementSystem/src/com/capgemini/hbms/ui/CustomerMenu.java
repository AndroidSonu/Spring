package com.capgemini.hbms.ui;

public enum CustomerMenu {

	REGISTER,LOGIN,EXIT;
}
