package com.capgemini.hbms.dao;


public interface IQueryMapper {
	
	
	//Admin login verification query
	public final  String GET_ADMIN = "SELECT user_id,password FROM users WHERE role = 'admin' AND user_id=?";
	
	//Admin operations queries
	
	// Hotel Operations
	public static final String INSERT_INTO_HOTEL = " INSERT INTO hotel(hotel_id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax)"
			+ "VALUES (hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String DELETE_HOTEL = " DELETE FROM hotel WHERE hotel_id = ? ";
	
	public static final String UPDATE_HOTEL = " UPDATE hotel SET description=?,avg_rate_per_night=? WHERE hotel_id=? " ;
	
	public static final String GET_CURRVAL_HOTEL = "SELECT hotel_id_seq.currval FROM DUAL";
	
	
	// Room operations
	
	public static final String INSERT_INTO_ROOM = " INSERT INTO roomdetails(hotel_id,room_id,room_no,room_type,per_night_rate,availability)"
			+ "VALUES (?,room_id_seq.nextval,?,?,?,?)";
	
	public static final String GET_CURRVAL_ROOM = "SELECT room_id_seq.currval FROM DUAL";
	
	public static final String DELETE_ROOM = " DELETE FROM roomdetails WHERE room_id = ? ";
	
	public static final String UPDATE_ROOM = " UPDATE roomdetails SET per_night_rate=? WHERE room_id = ? " ;
	
	// Generate List
	
	public static final String GET_HOTEL_LIST = "SELECT hotel_id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax FROM hotel";
	
	public static final String GET_BOOKING_LIST_BY_HOTEL_ID = "SELECT bd.booking_id,bd.booked_from,bd.booked_to,bd.no_of_adults,bd.no_of_children,bd.amount,bd.room_id,bd.user_id FROM bookingdetails bd JOIN roomdetails rd ON bd.room_id=rd.room_id  WHERE rd.hotel_id=?";
	
	public static final String GET_BOOKING_LIST_BY_DATE = "SELECT booking_id,booked_from,booked_to,no_of_adults,no_of_children,amount,room_id,user_id FROM bookingdetails WHERE booked_from=?";
	
	//Booking Details insertion
	public static final String INSERT_INTO_BOOKING = "INSERT INTO bookingdetails (booking_id,booked_from,booked_to,no_of_adults,no_of_children,amount,room_id,user_id)"
			+"VALUES (booking_id_seq.nextval,?,?,?,?,?,?,?)";

	public static final String GET_CURRVAL_BOOKINGID = "SELECT booking_id_seq.currval FROM DUAL";
	
	//for rate per night of room
	public static final String FIND_RATE_PER_NIGHT_OF_ROOM = "SELECT per_night_rate FROM roomdetails WHERE room_id=?";
	
	// Customer operations
	
	//Register
	public static final String REGISTER_USER = "INSERT INTO users(user_id,password,role,user_name,mobile_no,phone,address,email) VALUES(user_id_seq.nextval,?,'CUSTOMER',?,?,?,?,?)";
	
	public static final String GET_CURRVAL_USER_ID = "SELECT user_id_seq.currval FROM DUAL ";
	
	//Customer Login
	public final  String GET_USER = "SELECT user_id ,password FROM users WHERE role = 'CUSTOMER' AND user_id =?";
	// search
	
	public static final String HOTEL_LIST_BY_CITY = "SELECT hotel_id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax FROM hotel WHERE city=?";
	
	public static final String ROOM_LIST_BY_HOTEL_ID = " SELECT hotel_id,room_id,room_no,room_type,per_night_rate,availability FROM roomdetails WHERE hotel_id=? AND room_type=? AND availability=1";
	
	//Booking
	
	public static final String BOOKING_DETAILS_BY_BOOKING_ID = "SELECT booking_id,booked_from,booked_to,no_of_adults,no_of_children,amount,room_id,user_id FROM bookingdetails WHERE booking_id=?";
	
	//Update Booking Availability
	public static final String UPDATE_ROOM_AVAILABILITY = "UPDATE roomdetails SET availability = 0 WHERE room_id=?";
	
	public static final String CHECK_ROOM_AVAILABILITY = "SELECT availability FROM roomdetails WHERE room_id=?";
	
	//Guest List
	public static final String GUEST_LIST_BY_HOTEL_ID = "SELECT DISTINCT ud.user_id,ud.user_name FROM USERS ud JOIN bookingdetails bd ON bd.user_id=ud.user_id JOIN roomdetails rd ON rd.room_id=bd.room_id WHERE hotel_id=?";
}
