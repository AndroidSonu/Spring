package com.capgemini.hbms.dao;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HotelException;

public interface IHotelDao {
	
	//verify admin login function
	public boolean verifyLogin(int id,String password) throws HotelException;
	public boolean verifyCustLogin(int id,String password) throws HotelException;
	
	
	//Admin operations
	
	//Hotel Operations
	public int addHotel(Hotel hotel) throws HotelException;
	public boolean deleteHotel(int hotelId) throws HotelException;
	public boolean modifyHotel(String hotelDesc,double avgRate,int hotelId) throws HotelException;
	
	//Room operations
	public int addRoom(RoomDetails room) throws HotelException;
	public boolean deleteRoom(int roomId) throws HotelException;
	public boolean modifyRoom(int roomId,double rent) throws HotelException;
	
	//Generate Lists 
	public List<Hotel> getHotelList() throws HotelException;
	public List<BookingDetails> getBookingDetails(int hotelId) throws HotelException;
	public List<BookingDetails> getBookingDetailsByDate(LocalDate bookingDate) throws HotelException;
	public List<Users> getGuestListByHotel_Id(int hotel_id) throws HotelException;
	//Add Booking Details
	public int addBookingDetails(BookingDetails bookingDetails) throws HotelException;
	
	//to calculate amount
	public double calculateBookingAmount(int room_id,String date1,String date2,int noOfPerson) throws HotelException;
	
	//Customer functions
	
	// search function
	
	public List<Hotel> getHotelListByCity(String city) throws HotelException;
	public List<RoomDetails> getRoomListByHotelIdAndType(int hotelId,String type) throws HotelException;
	public List<BookingDetails> getBookingDetailsByBookingId(int bookingId) throws HotelException;
	
	//user registration
	public int addUser(Users user) throws HotelException;
	
	//Update Room Availability
	public int updateRoomAvailability(int room_id) throws HotelException;
}
