package com.capgemini.hbms.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.dao.HotelDaoImpl;
import com.capgemini.hbms.dao.IHotelDao;
import com.capgemini.hbms.exception.HotelException;

public class HotelServiceImpl implements IHotelService {

	IHotelDao dao = null;
	
	public HotelServiceImpl() {
		try {
			dao = new HotelDaoImpl();
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// Verify Admin
	
	@Override
	public boolean verifyLogin(int id, String password)
			throws HotelException {
		return dao.verifyLogin(id, password);
	}
	
	// verify Customer Login
	
	@Override
	public boolean verifyCustLogin(int id, String password)
			throws HotelException {
		return dao.verifyCustLogin(id, password);
	}
	
	//Hotel Function Def
	
	@Override
	public int addHotel(Hotel hotel) throws HotelException {
		int result = dao.addHotel(hotel);
		return result;
	}
	@Override
	public boolean deleteHotel(int hotelId) throws HotelException {
		boolean result = dao.deleteHotel(hotelId);
		return result;
	}
	@Override
	public boolean modifyHotel(String hotelDesc,double avgRate, int hotelId) throws HotelException {
		boolean result = dao.modifyHotel(hotelDesc,avgRate, hotelId);
		return result;
	}
	
	// Room Functions def
	
	@Override
	public int addRoom(RoomDetails room) throws HotelException {
		return dao.addRoom(room);
	}
	@Override
	public boolean deleteRoom(int roomId) throws HotelException {
		
		return dao.deleteRoom(roomId);
	}
	@Override
	public boolean modifyRoom(int roomId, double rent) throws HotelException {
		
		return dao.modifyRoom(roomId, rent);
	}

	// Generating report for admin
	
	@Override
	public List<Hotel> getHotelList() throws HotelException {
		return dao.getHotelList();
	}
	
	@Override
	public List<BookingDetails> getBookingDetails(int hotelId)
			throws HotelException {
		return dao.getBookingDetails(hotelId);
	}

	@Override
	public List<BookingDetails> getBookingDetailsByDate(LocalDate bookingDate)
			throws HotelException {
		return dao.getBookingDetailsByDate(bookingDate);
	}
	
	//Adding to booking details
	@Override
	public int addBookingDetails(BookingDetails bookingDetails)
			throws HotelException {
		return dao.addBookingDetails(bookingDetails);
	}

	@Override
	public double calculateBookingAmount(int room_id, String date1,
			String date2, int noOfPerson) throws HotelException {
		// TODO Auto-generated method stub
		return dao.calculateBookingAmount(room_id, date1, date2, noOfPerson);
	}

	@Override
	public List<Hotel> getHotelListByCity(String city) throws HotelException {
		// TODO Auto-generated method stub
		return dao.getHotelListByCity(city);
	}

	@Override
	public List<RoomDetails> getRoomListByHotelIdAndType(int hotelId,
			String type) throws HotelException {
		// TODO Auto-generated method stub
		return dao.getRoomListByHotelIdAndType(hotelId, type);
	}

	@Override
	public List<BookingDetails> getBookingDetailsByBookingId(int bookingId)
			throws HotelException {
		return dao.getBookingDetailsByBookingId(bookingId);
	}

	@Override
	public int addUser(Users user) throws HotelException {
		return dao.addUser(user);
	}

	@Override
	public int updateRoomAvailability(int room_id) throws HotelException {
		return dao.updateRoomAvailability(room_id);
	}

	@Override
	public List<Users> getGuestListByHotel_Id(int hotel_id)
			throws HotelException {
		return dao.getGuestListByHotel_Id(hotel_id);
	}
}
