package com.capgemini.hbms.test;
 
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
 
import java.time.LocalDate;
import java.time.Month;
 
import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
 
import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.dao.HotelDaoImpl;
import com.capgemini.hbms.dao.IHotelDao;
import com.capgemini.hbms.exception.HotelException;
 
public class TestHotelDaoImpl {
 
	IHotelDao dao=null;
 
	@Before
	public void setUp() throws Exception {
		dao=new HotelDaoImpl();
		PropertyConfigurator.configure("resources/log4j.properties");
	}
 
	@After
	public void tearDown() throws Exception {
	}
 
//	@Test
//	public void test() {
//		fail("Not yet implemented");
//	}
 
 
	@Test
	public void testAddNullHotel() {
		try {
			Hotel input = null;
			boolean expected = false;
			boolean actual = ((dao.addHotel(input) >60)?true:false);
			assertTrue(expected == actual);
		} catch (HotelException e) {
			fail("Did not expect exception");
		}
	}
 
	@Test
	public void testAddNotNullHotel() {
		try {
			Hotel input=new Hotel();
			//input.setHotelId(10);
			input.setCity("Ranchi");
			input.setHotelName("RoyalRetreat");
			input.setAddress("BootyMore");
			input.setDescription("Best");
			input.setAvgRatePerNight(950);
			input.setPhoneNo1("8123456881");
			input.setPhoneNo2("5934135550");
			input.setRating(4);
			input.setEmail("taj@g.com");
			input.setFax("8596231400");
			boolean expected = true;
			boolean actual = ((dao.addHotel(input) <=60)?true:false);
			assertTrue(expected == actual);
		} catch (HotelException e) {
			fail("Failed to add new Student exception " + e);
		}
		}
	@Test(expected = Exception.class)
	public void testAddNotNullHotelWithInsufficientData()
			throws HotelException {
	     Hotel input = new Hotel();
		input.setCity("Bangalore");
		dao.addHotel(input);
		fail("Expecting an Exception");
	}
 
 
	@Test
	public void testAddNullRoom() {
		try {
			RoomDetails input = null;
			boolean expected = false;
			boolean actual = ((dao.addRoom(input) > 600)?true:false);
			assertTrue(expected == actual);
		} catch (HotelException e) {
			fail("Did not expect exception");
		}
	}
	@Test
	public void testAddNotNullRoom() {
		try {
 
			RoomDetails input=new RoomDetails();
			input.setRoomNo(101);
			input.setRoomType("NON_AC");
			input.setPerNightRate(700);
			input.setAvailability(1);
			input.setHotelId(21);
			boolean expected = true;
			boolean actual = ((dao.addRoom(input) <=600)?true:false);
			assertTrue(expected == actual);
		} catch (HotelException e) {
			fail("Did not expect exception");
		}
	}
 
	@Test(expected = Exception.class)
	public void testAddNotNullRoomWithInsufficientData()
			throws HotelException {
	RoomDetails input = new RoomDetails();
		input.setRoomNo(105);
		dao.addRoom(input);
		fail("Expecting an Exception");
	}
 
 
	@Test
	public void testAddNullUser() {
		try {
			Users input = null;
			boolean expected = false;
			boolean actual = ((dao.addUser(input) > 1200)?true:false);
			assertTrue(expected == actual);
		} catch (HotelException e) {
			fail("Did not expect exception");
		}
	}
	@Test
	public void testAddNotNullUser() {
		try {
			Users input=new Users();
			input.setPassword("sachin");
	        input.setRole("user");
	        input.setUserName("anurag");
	        input.setMobileNo("1023456789");
	        input.setPhone("1598745832");
	        input.setAddress("Mumbai");
	        input.setEmail("sehe@g.in");
	        boolean expected = true;
			boolean actual = ((dao.addUser(input) <=1200)?true:false);
			assertTrue(expected == actual);
		} catch (HotelException e) {
			fail("Did not expect exception");
		}
	}
 
 
	@Test(expected = Exception.class)
	public void testAddNotNullUserWithInsufficientData()
			throws HotelException {
	Users input = new Users();
		input.setPassword("rahul");
		dao.addUser(input);
		fail("Expecting an Exception");
	}
 
	@Test
	public void testAddNullBookingDetails() {
		try {
			BookingDetails input = null;
			boolean expected = false;
			boolean actual = ((dao.addBookingDetails(input) > 50000)?true:false);
			assertTrue(expected == actual);
		} catch (HotelException e) {
			fail("Did not expect exception");
		}
	}
 
	@Test
	public void testAddNotNullBookingDetails() {
		try {
	         BookingDetails input=new BookingDetails();
	         input.setBookedFrom(LocalDate.of(2017, Month.DECEMBER, 5));
	         input.setBookedTo(LocalDate.of(2017, Month.DECEMBER, 7));
	         input.setNoOfAdults(2);
	         input.setNoOfChildren(0);
	         input.setAmount(1500);
	         input.setRoomId(102);
	         input.setUserId(1001);
	         boolean expected = true;
				boolean actual = ((dao.addBookingDetails(input) <=50000)?true:false);
				assertTrue(expected == actual);
			} catch (HotelException e) {
				fail("Did not expect exception");
			}
		}
	@Test(expected = Exception.class)
	public void testAddNotNullBookingDetailsWithInsufficientData()
			throws HotelException {
	BookingDetails input = new BookingDetails();
		input.setNoOfAdults(2);
		dao.addBookingDetails(input);
		fail("Expecting an Exception");
	}
}