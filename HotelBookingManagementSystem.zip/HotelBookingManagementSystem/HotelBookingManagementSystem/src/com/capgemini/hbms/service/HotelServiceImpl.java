package com.capgemini.hbms.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.dao.HotelDaoImpl;
import com.capgemini.hbms.dao.IHotelDao;
import com.capgemini.hbms.exception.HotelException;

public class HotelServiceImpl implements IHotelService {

	IHotelDao dao = null;
	private List<String> validationErrors;
	
	public HotelServiceImpl() throws HotelException {
			dao = new HotelDaoImpl();
	}
	
	//--------------------------------------------Validating Hotel-------------------------------------------
	public boolean isValidName(String Name){
		
		Pattern namePattern = Pattern.compile("[A-Z]{1}[a-z//s]{3,10}");
		Matcher nameMatcher = namePattern.matcher(Name);
		return nameMatcher.matches();
	}
	
	public boolean isValidAddress(String address){
		
		Pattern namePattern = Pattern.compile("[A-z//s]{4,25}");
		Matcher nameMatcher = namePattern.matcher(address);
		return nameMatcher.matches();
	}
	
	public boolean isValidMobileNumber(String mobileNumber){
		Pattern mobileNumberPattern = Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher mobileMatcher = mobileNumberPattern.matcher(mobileNumber);
		return mobileMatcher.matches();
	}
	
	public boolean isValidRating(int rating){
		if(rating <0 || rating >5)
			return false;
		else
			return true;
	}
	
	public boolean isValidEmail(String emailId)
	{
		Pattern emailPattern = Pattern
				.compile("[a-z]+([._]|[a-z]|[0-9])+@[a-z]+.[a-z]+(.[a-z]+)?");
		Matcher emailMatcher = emailPattern.matcher(emailId);
		return emailMatcher.matches();
	}
	
	public boolean isValidHotel(Hotel hotel) {
		validationErrors = new ArrayList<>();

		if (hotel != null) {
			if (!isValidName(hotel.getHotelName())) {
				validationErrors
						.add("First name must start with UpperCase Letters");
			}
			
			if (!isValidName(hotel.getCity())) {
				validationErrors
						.add("First name must start with UpperCase Letters");
			}
			
			if (!isValidAddress(hotel.getAddress())) {
				validationErrors
						.add("Address Should only be characters minimum=6 and maximum=25 characters");
			}
			
			if (!isValidName(hotel.getDescription())) {
				validationErrors
						.add("Description must start with UpperCase Letters");
			}
			
			if (!isValidMobileNumber(hotel.getPhoneNo1())) {
				validationErrors.add("Phone Number 01 can have only 10 digits");
			}
			
			if (!isValidMobileNumber(hotel.getPhoneNo2())) {
				validationErrors
						.add("Phone Number 02 can have only 10 digits");
			}
			
			if (!isValidEmail(hotel.getEmail())) {
				validationErrors.add("Invalid EmailId");
			}
			
			if (!isValidRating(hotel.getRating())) {
				validationErrors.add("Rating can be Numbers between 0 and 5");
			}
			
			if (!isValidMobileNumber(hotel.getFax())) {
				validationErrors
						.add("Fax Number can have only 10 digits");
			}

		}

		return validationErrors.size() == 0 ? true : false;

	}
	//----------------------------------------------Hotel validation Done-----------------------------------------
	
	
	
	//--------------------------------------------Validating Room-------------------------------------------------
	public boolean isValidAvailability(int availability)
	{
		if(availability==0||availability==1)
			return true;
		else
			return false;
	}
	
	public boolean isValidId(int id)
	{
		if(id>0)
			return true;
		else
			return false;
	}
	public boolean isValidRoom(RoomDetails roomDetails) {
		validationErrors = new ArrayList<>();

		if (roomDetails != null) {
			if (!(roomDetails.getRoomType().equals("AC") || roomDetails.getRoomType().equals("NON_AC"))) {
				validationErrors
						.add("Room Type Can be Only 'AC' or 'NON_AC'");
			}
			
			if (!isValidAvailability(roomDetails.getAvailability())) {
				validationErrors
						.add("Availability can be either 0(Not Available) or 1(Available)");
			}
			
			if (!isValidId(roomDetails.getRoomNo())) {
				validationErrors
						.add("Room No must be in numbers");
			}
			
			if (!isValidId(roomDetails.getHotelId())) {
				validationErrors
						.add("Hotel Id must be in numbers");
			}
		}

		return validationErrors.size() == 0 ? true : false;

	}
	//------------------------------------------Room Validation Done-----------------------------------------
	
	
	//--------------------------------------------Validating User--------------------------------------------
	
	public boolean isValidPassword(String empPassword){
		Pattern passwordPattern = Pattern.compile(".{4,}");
		Matcher passwordMatcher = passwordPattern.matcher(empPassword);
		
		return passwordMatcher.matches();
		
	}
	
	public boolean isValidUser(Users user) {
		validationErrors = new ArrayList<>();

		if (user != null) {
			if (!isValidPassword(user.getPassword())) {
				validationErrors
						.add("Password must contain 4 or more characters");
			}
			
			if (!isValidName(user.getUserName())) {
				validationErrors
						.add("First name must start with UpperCase Letters");
			}
			
			if (!isValidMobileNumber(user.getMobileNo())) {
				validationErrors
						.add("Mobile Number can have only 10 digits");
			}
			
			if (!isValidMobileNumber(user.getPhone())) {
				validationErrors
						.add("Phone Number can have only 10 digits");
			}
			
			if (!isValidAddress(user.getAddress())) {
				validationErrors
						.add("Address Should only be characters minimum=4 and maximum=25 characters");
			}
			
			if (!isValidEmail(user.getEmail())) {
				validationErrors.add("Invalid EmailId");
			}
		}

		return validationErrors.size() == 0 ? true : false;

	}
	//------------------------------------------User Validation Done-----------------------------------------
	
	
	//---------------------------------------Booking Details Validation--------------------------------------
	
	public boolean isValidAdultAndChildren(int number)
	{
		if(number>0)
			return true;
		else
			return false;
	}
	
	public boolean isValidBooking(BookingDetails bookingDetails) {
		validationErrors = new ArrayList<>();

		if (bookingDetails != null) {
			if (bookingDetails.getBookedTo().isBefore(bookingDetails.getBookedFrom())) {
				validationErrors
						.add("CheckIn Date Should be Before CheckOut Date");
			}
			
			if (!isValidAdultAndChildren(bookingDetails.getNoOfAdults())) {
				validationErrors
						.add("Number Should be greater than zero");
			}
			
			if (!isValidAdultAndChildren(bookingDetails.getNoOfChildren())) {
				validationErrors
						.add("Number Should be greater than zero");
			}
			
		}

		return validationErrors.size() == 0 ? true : false;

	}
	//---------------------------------------Booking Details Validation Done-----------------------------------
	
	
	// -----------------------------------------Verify Admin-------------------------------------------------
	
	@Override
	public boolean verifyLogin(int id, String password)
			throws HotelException {
		return dao.verifyLogin(id, password);
	}
	
	// --------------------------------------verify Customer Login-------------------------------------------
	
	@Override
	public boolean verifyCustLogin(int id, String password)
			throws HotelException {
		return dao.verifyCustLogin(id, password);
	}
	
	//----------------------------------------Hotel Function Def----------------------------------------------
	
	@Override
	public int addHotel(Hotel hotel) throws HotelException {
		int result=-1;
		if(isValidHotel(hotel)){
		result = dao.addHotel(hotel);
		}else{
			throw new HotelException("Invalid Hotel Details!"
					+ "\n"+validationErrors);
		}
		return result;
	}
	@Override
	public boolean deleteHotel(int hotelId) throws HotelException {
		boolean result = dao.deleteHotel(hotelId);
		return result;
	}
	@Override
	public boolean modifyHotel(String hotelDesc,double avgRate, int hotelId) throws HotelException {
		boolean result = dao.modifyHotel(hotelDesc,avgRate, hotelId);
		return result;
	}
	
	// Room Functions def
	
	@Override
	public int addRoom(RoomDetails room) throws HotelException {
		int result=-1;
		if(isValidRoom(room)){
			result=dao.addRoom(room);
		}else{
			throw new HotelException("Invalid Romm Details!"
					+ "\n"+validationErrors);
		}
		return result;
		
	}
	@Override
	public boolean deleteRoom(int roomId) throws HotelException {
		
		return dao.deleteRoom(roomId);
	}
	@Override
	public boolean modifyRoom(int roomId, double rent) throws HotelException {
		
		return dao.modifyRoom(roomId, rent);
	}

	// Generating report for admin
	
	@Override
	public List<Hotel> getHotelList() throws HotelException {
		return dao.getHotelList();
	}
	
	@Override
	public List<BookingDetails> getBookingDetails(int hotelId)
			throws HotelException {
		return dao.getBookingDetails(hotelId);
	}

	@Override
	public List<BookingDetails> getBookingDetailsByDate(LocalDate bookingDate)
			throws HotelException {
		return dao.getBookingDetailsByDate(bookingDate);
	}
	
	//Adding to booking details
	@Override
	public int addBookingDetails(BookingDetails bookingDetails)
			throws HotelException {
		return dao.addBookingDetails(bookingDetails);
	}

	@Override
	public double calculateBookingAmount(int room_id, String date1,
			String date2, int noOfPerson) throws HotelException {
		// TODO Auto-generated method stub
		return dao.calculateBookingAmount(room_id, date1, date2, noOfPerson);
	}

	@Override
	public List<Hotel> getHotelListByCity(String city) throws HotelException {
		// TODO Auto-generated method stub
		return dao.getHotelListByCity(city);
	}

	@Override
	public List<RoomDetails> getRoomListByHotelIdAndType(int hotelId,
			String type) throws HotelException {
		// TODO Auto-generated method stub
		return dao.getRoomListByHotelIdAndType(hotelId, type);
	}

	@Override
	public List<BookingDetails> getBookingDetailsByBookingId(int bookingId)
			throws HotelException {
		return dao.getBookingDetailsByBookingId(bookingId);
	}
	
	//--------------------------------ADDING USER---------------------------------------------
	
	@Override
	public int addUser(Users user) throws HotelException {
		int result=-1;
		if(isValidUser(user)){
			result=dao.addUser(user);
		}else{
			throw new HotelException("Invalid User Details!"
					+ "\n"+validationErrors);
		}
		return result;
		
	}

	@Override
	public int updateRoomAvailability(int room_id) throws HotelException {
		return dao.updateRoomAvailability(room_id);
	}

	@Override
	public List<Users> getGuestListByHotel_Id(int hotel_id)
			throws HotelException {
		return dao.getGuestListByHotel_Id(hotel_id);
	}

	@Override
	public List<RoomDetails> getRoom_Id_From_Database(int room_id)
			throws HotelException {
		return dao.getRoom_Id_From_Database(room_id);
	}

	@Override
	public boolean userDetailsCheck(int user_id) throws HotelException {
		return dao.userDetailsCheck(user_id);
	}
}
