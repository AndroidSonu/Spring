package com.capgemini.hbms.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HotelException;
import com.capgemini.hbms.util.ConnectionProvider;

public class HotelDaoImpl implements IHotelDao {

	private Logger classLogger;
	private ConnectionProvider connProvider;

	public HotelDaoImpl() throws HotelException {
		classLogger = Logger.getLogger(HotelDaoImpl.class);
		try {
			connProvider = ConnectionProvider
					.getInstance("resources/dbConfig.properties");
		} catch (ClassNotFoundException | IOException exp) {
			classLogger.error(exp);
			throw new HotelException("Data Access Initiation Failed");

		}

	}

	public Users mapRowUser(ResultSet result) throws HotelException {
		Users user = new Users();

		try {
			user.setUserId(result.getInt("user_id"));
			user.setUserName(result.getString("user_name"));
			/*
			 * user.setPassword(result.getString("password"));
			 * user.setRole(result.getString("role"));
			 * user.setMobileNo(result.getString("mobile_no"));
			 * user.setAddress(result.getString("address"));
			 * user.setPhone(result.getString("phone"));
			 * user.setEmail(result.getString("email"));
			 */
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Could not Retrive Data");
		}
		return user;
	}

	public Hotel mapRowHotel(ResultSet result) throws HotelException {
		Hotel hotel = new Hotel();

		try {
			hotel.setHotelId(result.getInt("hotel_id"));
			hotel.setCity(result.getString("city"));
			hotel.setHotelName(result.getString("hotel_name"));
			hotel.setAddress(result.getString("address"));
			hotel.setDescription(result.getString("description"));
			hotel.setAvgRatePerNight(result.getDouble("avg_rate_per_night"));
			hotel.setPhoneNo1(result.getString("phone_no1"));
			hotel.setPhoneNo2(result.getString("phone_no2"));
			hotel.setRating(result.getInt("rating"));
			hotel.setEmail(result.getString("email"));
			hotel.setFax(result.getString("fax"));

		} catch (SQLException exp) {

			classLogger.error(exp);
			throw new HotelException("Could not Retrive Data");
		}
		return hotel;
	}

	public RoomDetails mapRowRoom(ResultSet result) throws HotelException {
		RoomDetails room = new RoomDetails();

		try {
			room.setHotelId(result.getInt("hotel_id"));
			room.setRoomId(result.getInt("room_id"));
			room.setRoomNo(result.getInt("room_no"));
			room.setRoomType(result.getString("room_type"));
			room.setPerNightRate(result.getDouble("per_night_rate"));
			room.setAvailability(result.getInt("availability"));

		} catch (SQLException exp) {

			classLogger.error(exp);
			throw new HotelException("Could not Retrive Data");
		}
		return room;
	}

	/*
	 * public RoomDetails mapRowRoomForId(ResultSet result) throws
	 * HotelException{ RoomDetails room = new RoomDetails();
	 * 
	 * try { room.setRoomId(result.getInt("room_id"));
	 * room.setAvailability(result.getInt("availability"));
	 * 
	 * } catch (SQLException exp) {
	 * 
	 * classLogger.error(exp); throw new
	 * HotelException("Could not Retrive Data"); } return room; }
	 */

	public BookingDetails mapBooking(ResultSet result) throws HotelException {
		BookingDetails bookingDetails = new BookingDetails();

		try {

			bookingDetails.setBookingId(result.getInt("booking_id"));
			bookingDetails.setBookedFrom(result.getDate("booked_from")
					.toLocalDate());
			bookingDetails.setBookedTo(result.getDate("booked_to")
					.toLocalDate());
			bookingDetails.setNoOfAdults(result.getInt("no_of_adults"));
			bookingDetails.setNoOfChildren(result.getInt("no_of_children"));
			bookingDetails.setAmount(result.getDouble("amount"));
			bookingDetails.setRoomId(result.getInt("room_id"));
			bookingDetails.setUserId(result.getInt("user_id"));

		} catch (SQLException exp) {

			classLogger.error(exp);
			throw new HotelException("Could not Retrive Data");
		}
		return bookingDetails;
	}

	@Override
	public boolean verifyLogin(int id, String password) throws HotelException {
		boolean status = false;
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepGetId = conn
						.prepareStatement(IQueryMapper.GET_ADMIN)) {

			prepGetId.setInt(1, id);
			ResultSet result = prepGetId.executeQuery();

			if (result.next()) {

				if (result.getInt("user_id") == id
						&& result.getString("password").equals(password)) {
					status = true;
				}
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Login");

		}
		return status;
	}

	@Override
	public boolean verifyCustLogin(int id, String password)
			throws HotelException {
		boolean status = false;
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepGetId = conn
						.prepareStatement(IQueryMapper.GET_USER)) {

			prepGetId.setInt(1, id);
			ResultSet result = prepGetId.executeQuery();

			if (result.next()) {

				if (result.getInt("user_id") == id
						&& result.getString("password").equals(password)) {
					status = true;
				}
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Login");

		}
		return status;
	}

	// admin functions definitions

	@Override
	public int addHotel(Hotel hotel) throws HotelException {
		int curr_id = -1;
		if (hotel != null) {

			try (Connection conn = connProvider.getConnection();
					PreparedStatement prepAdd = conn
							.prepareStatement(IQueryMapper.INSERT_INTO_HOTEL);
					PreparedStatement prepCurrId = conn
							.prepareStatement(IQueryMapper.GET_CURRVAL_HOTEL)) {

				classLogger.debug(hotel + " added ");
				prepAdd.setString(1, hotel.getCity());
				prepAdd.setString(2, hotel.getHotelName());
				prepAdd.setString(3, hotel.getAddress());
				prepAdd.setString(4, hotel.getDescription());
				prepAdd.setDouble(5, hotel.getAvgRatePerNight());
				prepAdd.setString(6, hotel.getPhoneNo1());
				prepAdd.setString(7, hotel.getPhoneNo2());
				prepAdd.setInt(8, hotel.getRating());
				prepAdd.setString(9, hotel.getEmail());
				prepAdd.setString(10, hotel.getFax());

				int count = prepAdd.executeUpdate();

				ResultSet results = prepCurrId.executeQuery();

				if (results.next()&&count!=0) {

					curr_id = results.getInt(1);
				}

			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new HotelException("Failed to Add Hotel");

			}
		}
		return curr_id;
	}

	@Override
	public boolean deleteHotel(int hotelId) throws HotelException {
		boolean result = false;

		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepDelete = conn
						.prepareStatement(IQueryMapper.DELETE_HOTEL)) {

			prepDelete.setInt(1, hotelId);

			int count = prepDelete.executeUpdate();

			if (count > 0) {
				return true;
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Delete Hotel");

		}

		return result;
	}

	@Override
	public boolean modifyHotel(String hotelDesc, double avgRate, int hotelId)
			throws HotelException {
		boolean result = false;
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepUpdate = conn
						.prepareStatement(IQueryMapper.UPDATE_HOTEL)) {

			prepUpdate.setString(1, hotelDesc);
			prepUpdate.setDouble(2, avgRate);
			prepUpdate.setInt(3, hotelId);

			int count = prepUpdate.executeUpdate();

			if (count > 0) {
				return true;
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Update Hotel");

		}
		return result;
	}

	// Room Functions def

	@Override
	public int addRoom(RoomDetails room) throws HotelException {
		int curr_id = -1;
		if (room != null) {

			try (Connection conn = connProvider.getConnection();
					PreparedStatement prepAdd = conn
							.prepareStatement(IQueryMapper.INSERT_INTO_ROOM);
					PreparedStatement prepCurrId = conn
							.prepareStatement(IQueryMapper.GET_CURRVAL_ROOM)) {

				classLogger.debug(room + " added ");
				prepAdd.setInt(1, room.getHotelId());
				prepAdd.setInt(2, room.getRoomNo());
				prepAdd.setString(3, room.getRoomType());
				prepAdd.setDouble(4, room.getPerNightRate());
				prepAdd.setDouble(5, room.getAvailability());

				int count = prepAdd.executeUpdate();

				ResultSet results = prepCurrId.executeQuery();

				if (results.next()&&count!=0) {
					curr_id = results.getInt(1);
				}
			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new HotelException("Failed to Add Room");

			}
		}
		return curr_id;
	}

	@Override
	public boolean deleteRoom(int roomId) throws HotelException {
		boolean result = false;

		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepDelete = conn
						.prepareStatement(IQueryMapper.DELETE_ROOM)) {

			prepDelete.setInt(1, roomId);

			int count = prepDelete.executeUpdate();

			if (count > 0) {
				return true;
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Delete Room");

		}

		return result;
	}

	@Override
	public boolean modifyRoom(int roomId, double rent) throws HotelException {
		boolean result = false;
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepUpdate = conn
						.prepareStatement(IQueryMapper.UPDATE_ROOM)) {

			prepUpdate.setInt(2, roomId);
			prepUpdate.setDouble(1, rent);

			int count = prepUpdate.executeUpdate();

			if (count > 0) {
				return true;
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Update Room");

		}
		return result;
	}

	// Generate List Def

	@Override
	public List<Hotel> getHotelList() throws HotelException {
		List<Hotel> hotels = new ArrayList<>();
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepGetAll = conn
						.prepareStatement(IQueryMapper.GET_HOTEL_LIST)) {

			ResultSet results = prepGetAll.executeQuery();

			while (results.next()) {
				hotels.add(mapRowHotel(results));
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Delete Employee");

		}
		return hotels;
	}

	@Override
	public List<BookingDetails> getBookingDetailsByDate(LocalDate bookingDate)
			throws HotelException {
		List<BookingDetails> bookingDetails = new ArrayList<>();
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepGetAll = conn
						.prepareStatement(IQueryMapper.GET_BOOKING_LIST_BY_DATE)) {
			prepGetAll.setDate(1, java.sql.Date.valueOf(bookingDate));
			ResultSet results = prepGetAll.executeQuery();

			while (results.next()) {
				bookingDetails.add(mapBooking(results));
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Retreive Booking Data");

		}
		return bookingDetails;
	}

	@Override
	public List<BookingDetails> getBookingDetails(int hotelId)
			throws HotelException {
		List<BookingDetails> bookingDetails = new ArrayList<>();
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepGetAll = conn
						.prepareStatement(IQueryMapper.GET_BOOKING_LIST_BY_HOTEL_ID)) {
			prepGetAll.setInt(1, hotelId);
			ResultSet results = prepGetAll.executeQuery();

			while (results.next()) {
				bookingDetails.add(mapBooking(results));
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Retreive Booking Data");

		}
		return bookingDetails;
	}

	@Override
	public int addBookingDetails(BookingDetails bookingDetails)
			throws HotelException {
		int curr_id = -1;
		if (bookingDetails != null) {

			try (Connection conn = connProvider.getConnection();
					PreparedStatement prepAdd = conn
							.prepareStatement(IQueryMapper.INSERT_INTO_BOOKING);
					PreparedStatement prepCurrId = conn
							.prepareStatement(IQueryMapper.GET_CURRVAL_BOOKINGID)) {

				classLogger.debug(bookingDetails + " added ");
				prepAdd.setDate(1,
						java.sql.Date.valueOf(bookingDetails.getBookedFrom()));
				prepAdd.setDate(2,
						java.sql.Date.valueOf(bookingDetails.getBookedTo()));
				prepAdd.setInt(3, bookingDetails.getNoOfAdults());
				prepAdd.setInt(4, bookingDetails.getNoOfChildren());
				prepAdd.setDouble(5, bookingDetails.getAmount());
				prepAdd.setInt(6, bookingDetails.getRoomId());
				prepAdd.setInt(7, bookingDetails.getUserId());

				int count = prepAdd.executeUpdate();

				ResultSet results = prepCurrId.executeQuery();

				if (results.next() && count!=0) {

					curr_id = results.getInt(1);
				}
			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new HotelException("Failed to Add Booking Details");

			}
		}
		return curr_id;
	}

	// Calculating Booking amount
	@Override
	public double calculateBookingAmount(int room_id, String date1,
			String date2, int noOfPerson) throws HotelException {
		double amount = 0;
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepAdd = conn
						.prepareStatement(IQueryMapper.FIND_RATE_PER_NIGHT_OF_ROOM);) {

			prepAdd.setInt(1, room_id);

			ResultSet results = prepAdd.executeQuery();

			if (results.next() && noOfPerson != 0) {

				double rate = results.getInt(1);
				DateTimeFormatter formatter = DateTimeFormatter
						.ofPattern("d/MM/yyyy");
				LocalDate from = LocalDate.parse(date1, formatter);
				LocalDate to = LocalDate.parse(date2, formatter);
				int dateDifference = Period.between(from, to).getDays();
				amount = rate * dateDifference * noOfPerson;
			}

			return amount;
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Find Rate From Room ID");

		}
	}

	@Override
	public List<Hotel> getHotelListByCity(String city) throws HotelException {
		List<Hotel> hotelListByCity = new ArrayList<>();
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepAdd = conn
						.prepareStatement(IQueryMapper.HOTEL_LIST_BY_CITY);) {

			prepAdd.setString(1, city);

			ResultSet results = prepAdd.executeQuery();

			while (results.next()) {
				hotelListByCity.add(mapRowHotel(results));
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Find Hotel List From this city");

		}
		return hotelListByCity;
	}

	@Override
	public List<RoomDetails> getRoomListByHotelIdAndType(int hotelId,
			String type) throws HotelException {
		List<RoomDetails> RoomListByHotelIdAndType = new ArrayList<>();
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepAdd = conn
						.prepareStatement(IQueryMapper.ROOM_LIST_BY_HOTEL_ID);) {

			prepAdd.setInt(1, hotelId);
			prepAdd.setString(2, type);

			ResultSet results = prepAdd.executeQuery();

			while (results.next()) {
				RoomListByHotelIdAndType.add(mapRowRoom(results));
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Find Rate From Room ID");

		}
		return RoomListByHotelIdAndType;
	}

	@Override
	public List<BookingDetails> getBookingDetailsByBookingId(int bookingId)
			throws HotelException {
		List<BookingDetails> bookingDetailsByBookingId = new ArrayList<>();
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepAdd = conn
						.prepareStatement(IQueryMapper.BOOKING_DETAILS_BY_BOOKING_ID);) {

			prepAdd.setInt(1, bookingId);

			ResultSet results = prepAdd.executeQuery();

			if (results.next()) {
				bookingDetailsByBookingId.add(mapBooking(results));
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException(
					"Failed to Find Booking Details From Booking ID");

		}
		return bookingDetailsByBookingId;
	}

	@Override
	public int addUser(Users user) throws HotelException {
		int curr_id = -1;
		if (user != null) {

			try (Connection conn = connProvider.getConnection();
					PreparedStatement prepAdd = conn
							.prepareStatement(IQueryMapper.REGISTER_USER);
					PreparedStatement prepCurrId = conn
							.prepareStatement(IQueryMapper.GET_CURRVAL_USER_ID)) {

				classLogger.debug(user + " added ");
				prepAdd.setString(1, user.getPassword());
				prepAdd.setString(2, user.getUserName());
				prepAdd.setString(3, user.getMobileNo());
				prepAdd.setString(4, user.getPhone());
				prepAdd.setString(5, user.getAddress());
				prepAdd.setString(6, user.getEmail());

				int count = prepAdd.executeUpdate();

				ResultSet results = prepCurrId.executeQuery();

				if (results.next() && count != 0) {

					curr_id = results.getInt(1);
				}

			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new HotelException("Failed to Register Customer");

			}
		}
		return curr_id;
	}

	@Override
	public int updateRoomAvailability(int room_id) throws HotelException {
		int result = 0;
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepUpdate = conn
						.prepareStatement(IQueryMapper.UPDATE_ROOM_AVAILABILITY)) {

			prepUpdate.setDouble(1, room_id);

			int count = prepUpdate.executeUpdate();

			if (count > 0) {
				return 1;
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Update Room Availability");

		}
		return result;

	}

	@Override
	public List<Users> getGuestListByHotel_Id(int hotel_id)
			throws HotelException {
		List<Users> user = new ArrayList<>();
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepGetAll = conn
						.prepareStatement(IQueryMapper.GUEST_LIST_BY_HOTEL_ID)) {

			prepGetAll.setInt(1, hotel_id);

			ResultSet results = prepGetAll.executeQuery();

			while (results.next()) {
				user.add(mapRowUser(results));
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Retrieve Data");

		}
		return user;
	}

	@Override
	public List<RoomDetails> getRoom_Id_From_Database(int room_id)
			throws HotelException {
		List<RoomDetails> RoomListByRoomIdAndType = new ArrayList<>();
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepAdd = conn
						.prepareStatement(IQueryMapper.ROOM_DATA_FROM_ROOM_ID);) {

			prepAdd.setInt(1, room_id);
			ResultSet results = prepAdd.executeQuery();

			while (results.next()) {
				RoomListByRoomIdAndType.add(mapRowRoom(results));
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Find Room Data");

		}
		return RoomListByRoomIdAndType;
	}

	@Override
	public boolean userDetailsCheck(int user_id) throws HotelException {
		boolean status = false;
		try (Connection conn = connProvider.getConnection();
				PreparedStatement prepGetId = conn
						.prepareStatement(IQueryMapper.GET_USER)) {

			prepGetId.setInt(1, user_id);
			ResultSet result = prepGetId.executeQuery();

			if (result.next()) {

				if (result.getInt("user_id") == user_id) {
					status = true;
				}
			}

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new HotelException("Failed to Find Data");

		}
		return status;

	}

}
