package com.cg.pa.dao;

import java.util.List;

import com.cg.pa.bean.Product;



public interface IProductDao {
	public boolean addProduct(Product product);
	public List<Product> getAllProduct();
	public Product purchase(int productId);
	public boolean update(Product product);

}
