package com.cg.pa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.pa.bean.Product;



@Repository
@Transactional
public class ProductDaoImpl implements IProductDao{

	@PersistenceContext
	EntityManager entityManager;
	@Override
	public boolean addProduct(Product product) {
		entityManager.persist(product);
		entityManager.flush();
		return true;
	}

	@Override
	public List<Product> getAllProduct() {
		TypedQuery query=entityManager.createQuery("from Product",Product.class);
		return query.getResultList();
	}

	@Override
	public Product purchase(int productId) {
		return entityManager.find(Product.class,productId);
		
	}

	@Override
	public boolean update(Product product) {
		entityManager.merge(product);
		return true;
	}

}
