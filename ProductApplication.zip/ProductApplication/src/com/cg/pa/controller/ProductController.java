package com.cg.pa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.pa.bean.Product;
import com.cg.pa.service.IProductService;


@Controller
public class ProductController {
	
	@Autowired
	IProductService service;

	public IProductService getService() {
		return service;
	}

	public void setService(IProductService service) {
		this.service = service;
	}
	
	ModelAndView mv;
	
	@RequestMapping("/homepage")
	public String showHomePage(){
		return "producthome";
	}
	
	@RequestMapping("/addproduct")
	public String addProductPage(){
		return "addproduct";
	}
	

	@RequestMapping(value="/addproductdetails",method=RequestMethod.POST)
	ModelAndView addProduct(@ModelAttribute("product") Product product,BindingResult result)
	{
		
		if(!result.hasErrors()){
		boolean status=service.addProduct(product);
		if(status==true){
		mv=new ModelAndView("addSuccess");
		}
		}
		else{
			mv=new ModelAndView("producterror","error","Something Went Wrong");
		}
		return mv;
	}
	
	@RequestMapping("/retrieveall")
	ModelAndView getProductDetails(){
		List<Product> productlist=service.getAllProduct();
		mv=new ModelAndView("productdetails","list",productlist);
		mv.addObject("isFirst","true");
		return mv;
	}
	
	@RequestMapping("/purchase")
	ModelAndView purchaseProduct(@RequestParam("productId") int productId){
		
		Product product=service.purchase(productId);
		mv=new ModelAndView("productdetails","prod",product);
		
		return mv;
	}
	
	@RequestMapping(value="/finalorder",method=RequestMethod.POST)
	ModelAndView OrderProduct(@ModelAttribute("product") Product product){
		Product p= service.purchase(product.getProductId());
		
		
		if(product.getProductQuantity()<=p.getProductQuantity() && p.getProductQuantity()>0){
			p.setProductQuantity(p.getProductQuantity()-product.getProductQuantity());
			service.update(p);
			double value=product.getProductQuantity()*product.getProductPrice();
			mv=new ModelAndView("finalorder","product",p);
			mv.addObject("result",value);
		}
		else{
			mv=new ModelAndView("producterror","error","Not Enough Stocks");
		}
		
		return mv;
	}
	
	
	
	
	
	
}
