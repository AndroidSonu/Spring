package com.cg.pa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pa.bean.Product;
import com.cg.pa.dao.IProductDao;


@Service
public class ProductService implements IProductService{

	@Autowired
	IProductDao dao;
	
	
	public IProductDao getDao() {
		return dao;
	}

	public void setDao(IProductDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean addProduct(Product product) {
		return dao.addProduct(product);
	}

	@Override
	public List<Product> getAllProduct() {
		return dao.getAllProduct();
	}

	@Override
	public Product purchase(int productId) {
		return dao.purchase(productId);
	}

	@Override
	public boolean update(Product product) {
		return dao.update(product);
	}

}
